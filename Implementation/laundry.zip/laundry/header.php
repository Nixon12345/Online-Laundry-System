<?php
session_start();
if(isset($_SESSION['user_id'])){
    if($_SESSION['user_id']=='Admin'){
        echo "<script type='text/javascript'>  window.location='admin-home.php'; </script>";
    }
}else{
    echo "<script type='text/javascript'>  window.location='signin.php'; </script>";
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>
        <?php
        include "functions/session-title.php";
        ?>
    </title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/custom.css" rel="stylesheet">
    <link rel="icon" href="assets/brand/washing-machine-favicon.png">
</head>
<body>
<header>
    <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">

        <a class="navbar-brand" href="user-home.php">
            <img src="assets/brand/washing-machine.png" style="max-height: 36px;max-width: 36px;">
            Laundry.com
        </a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarCollapse">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="request-service.php">Request Service</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Hy <?php echo $_SESSION['name']; ?></a>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="my-request.php">My Request</a>
                        <a class="dropdown-item" href="changepassword.php">Change Password</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="logout.php">Logout</a>
                    </div>
                </li>
            </ul>
        </div>
    </nav>
</header>

<main role="main">