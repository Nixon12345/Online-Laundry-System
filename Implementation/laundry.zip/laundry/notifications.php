<?php
session_start();
include "class/request.php";
$request = new request();
include "functions/message.php";
if(isset($_SESSION['user_id'])){
    if($_SESSION['user_id']!='Admin'){
        echo "<script type='text/javascript'>  window.location='user-home.php'; </script>";
    }
}else{
    echo "<script type='text/javascript'>  window.location='signin.php'; </script>";
}

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Admin | Notifications</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="assets/css/admin.css" rel="stylesheet">
    <!-- Favicon-->
    <link rel="icon" href="assets/brand/washing-machine-favicon.png">

</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg fixed-top navbar-dark bg-dark">
    <a class="navbar-brand mr-auto mr-lg-0" href="admin-home.php">
        <img src="assets/brand/washing-machine.png" style="max-height: 36px;max-width: 36px;">
        Administrator Dashboard
    </a>
</nav>

<div class="nav-scroller bg-white shadow-sm">
    <nav class="nav nav-underline">
        <a class="nav-link" href="admin-home.php">Users</a>
        <a class="nav-link active" href="notifications.php">
            Notifications
            <span class="badge badge-pill bg-light align-text-bottom"><?php echo $request->countNewNotifications(); ?></span>
        </a>
        <a class="nav-link" href="clothes.php">Clothes</a>
        <a class="nav-link" href="logout.php">Logout</a>
    </nav>
</div>

<main role="main" class="container">

    <?php
    if(isset($_GET['form_token'])){
        $requestServices = $request->getRequestService($_GET['form_token']);
        echo '<div class="my-3 p-3 bg-white rounded shadow-sm">';
        echo '<h6 class="border-bottom border-gray pb-2 mb-0">Services</h6>';
        foreach ($requestServices as $rsRow){
            echo '<div class="media text-muted pt-3">';
            echo '<div class="media-body pb-3 mb-0 small lh-125 border-bottom border-gray">';
            echo '<div class="d-flex justify-content-between align-items-center w-100">';
            echo '<strong class="text-gray-dark">'.$rsRow["cloth"].'</strong>';
            echo '</div>';
            echo '<span class="d-block">
                        <strong>Rate : </strong>£'.$rsRow["rate"].'<br>
                        <strong>Quantity : </strong>'.$rsRow["quantity"].'
                  </span>';
            echo '</div>';
            echo '</div>';
        }
        echo '</div>';
    }
    ?>


    <div class="my-3 p-3 bg-white rounded shadow-sm">
        <h6 class="border-bottom border-gray pb-2 mb-0">Requests</h6>

        <?php
        if(!$request->getUserRequest()){
            danger_message('Sorry','0 Request.');
        }else{
            $allRequest = $request->getUserRequest();
            foreach ($allRequest as $requestRow){
                echo '<div class="media text-muted pt-3">';
                echo '<div class="media-body pb-3 mb-0 small lh-125 border-bottom border-gray">';
                echo '<div class="d-flex justify-content-between align-items-center w-100">';
                echo '<strong class="text-gray-dark">'.$requestRow["name"].'</strong>';
                if(!$requestRow['form_complete']){
                    echo '<td><span class="badge badge-pill badge-danger">Not Completed Form</span></td>';
                }
                if(!$requestRow['status']){
                    echo '<a href="confirm_request.php?adminConfirm='.$requestRow["form_token"].'" class="btn btn-success btn-sm">Confirm</a>';
                }
                echo '</div>';
                echo '<span class="d-block">
                        <strong>Date : </strong>'.$requestRow["request_date"].'<br>
                        <strong>Time : </strong>'.$requestRow["request_time"].'<br>
                        <strong>Total : </strong>£'.$requestRow["total"].'<br>
                        <strong>Requested at : </strong>'.$requestRow["date"].'<br>
                        <a href="notifications.php?form_token='.$requestRow["form_token"].'" class="btn btn-info">View</a></span>';
                echo '</div>';
                echo '</div>';
            }
        }
        ?>

    </div>
</main>
<script src="assets/js/jquery-3.3.1.slim.min.js"></script>
<script>window.jQuery || document.write('<script src="assets/js/jquery-3.3.1.slim.min.js"><\/script>')</script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>
