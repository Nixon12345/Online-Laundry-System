<?php

$connection = mysqli_connect("127.0.0.1","root","");
$checkDb = mysqli_select_db($connection,"laundry");
if(!$checkDb){
    header('location:setup.php');
}

session_start();
include "class/request.php";
$request = new request();
if(isset($_SESSION['user_id'])){
    if($_SESSION['user_id']=='Admin'){
        echo "<script type='text/javascript'>  window.location='admin-home.php'; </script>";
    }else{
        echo "<script type='text/javascript'>  window.location='user-home.php'; </script>";
    }
}

?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>
        <?php
        $_SESSION['title']='';
        if($_SESSION['title']){
            echo $_SESSION['title'];
        }else{
            echo "Welcome | Laundry.com";
        }
        ?>
    </title>

    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/custom.css" rel="stylesheet">
    <link rel="icon" href="assets/brand/washing-machine-favicon.png">
</head>

<body>

<header>
    <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">

        <a class="navbar-brand" href="index.php">
        <img src="assets/brand/washing-machine.png" class="brand-image">
            Laundry.com
        </a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarCollapse">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="signin.php">Sign in</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="signup.php">Sign up</a>
                </li>
            </ul>
        </div>
    </nav>
</header>

<main role="main">

    <div id="myCarousel" class="carousel slide" data-ride="carousel">

        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img class="re" src="assets/images/laundry1.jpg" alt="Laundry.com">
                <div class="container">
                    <div class="carousel-caption text-left">
                        <h1>Laundry.com</h1>
                        <p>You leave it we clean it!</p>
                        <p><a class="btn btn-lg btn-primary" href="signup.php" role="button">Sign up today</a></p>
                    </div>
                </div>
            </div>
            <div class="carousel-item">
                <img src="assets/images/laundry2.jpg" alt="Laundry.com">
                <div class="container">
                    <div class="carousel-caption">
                        <h1>Laundry.com</h1>
                        <p>Shine like crystal.</p>
                        <p><a class="btn btn-lg btn-primary" href="signup.php" role="button">Sign up today</a></p>
                    </div>
                </div>
            </div>
            <div class="carousel-item">
                <img src="assets/images/laundry3.jpg" alt="Laundry.com">
                <div class="container">
                    <div class="carousel-caption text-right">
                        <h1>Laundry.com</h1>
                        <p>Smell me, I'm clean</p>
                        <p><a class="btn btn-lg btn-primary" href="signup.php" role="button">Sign up today</a></p>
                    </div>
                </div>
            </div>
        </div>
        <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>

    <div class="container marketing">

        <div class="row">

            <?php
            $clothes = $request->getClothes()->selectAllClothes();
            $getAllClothes = $request->getUser()->getConfig()->select($clothes);
            foreach ($getAllClothes as $allClothes){
                echo '<div class="col-lg-4">';
                echo '<img src="assets/images/'.$allClothes['cloth_image'].'" class="bd-placeholder-img rounded-circle" width="140" height="140" />';
                echo '<h2>'.$allClothes['cloth'].'</h2>';
                echo '<p>Price (Per Piece) : £'.$allClothes['rate'].' </p>';
                    echo '</div><!-- /.col-lg-4 -->';
            }
            ?>

        </div><!-- /.row -->

        <hr class="featurette-divider">

    </div><!-- /.container -->


    <!-- FOOTER -->
    <footer class="container">
        <p class="float-right"><a href="#">Back to top</a></p>
        <p>&copy; 2019 Laundry.com</p>
    </footer>

</main>

<script src="assets/js/jquery-3.3.1.slim.min.js"></script>
<script>window.jQuery || document.write('<script src="assets/js/jquery-3.3.1.slim.min.js"><\/script>')</script>
<script src="assets/js/bootstrap.bundle.min.js"></script>

</body>
</html>
