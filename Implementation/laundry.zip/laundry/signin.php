<?php
session_start();
if(isset($_SESSION['user_id'])){
    if($_SESSION['user_id']=='Admin'){
        echo "<script type='text/javascript'>  window.location='admin-home.php'; </script>";
    }else{
        echo "<script type='text/javascript'>  window.location='user-home.php'; </script>";
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>
        Sign in
    </title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="assets/css/signin.css" rel="stylesheet">
    <!-- Favicon-->
    <link rel="icon" href="assets/brand/washing-machine-favicon.png">


</head>

<body class="text-center">

<form class="form-signin" method="post">

    <?php
    include "class/user.php";
    $user = new user();
    include "functions/message.php";
    if(isset($_POST['signin_btn'])){
        if($_POST['email']=="" || $_POST['password']==""){
            danger_message('Sorry','Please fill up all the fields.');
        }else{
            $user->setEmail($_POST['email']);
            $user->setPassword($_POST['password']);

            if($user->user_login()=="email-not-exists"){
                danger_message('Sorry','Email does not exists.');
            }elseif ($user->user_login()=="password-not-match"){
                danger_message('Sorry','Password does not match.');
            }
        }
    }
    ?>

    <h1 class="h3 mb-3 font-weight-normal">Laundry.com</h1>
    <img class="mb-4" src="assets/brand/washing-machine.svg" alt="brand image" width="72" height="72">
    <h2 class="h4 mb-4 font-weight-normal">Please sign in</h2>
    <input type="email" class="form-control" placeholder="Email Address" name="email" autofocus>
    <input type="password" class="form-control" placeholder="Password" name="password">
    <button class="btn btn-lg btn-primary btn-block" type="submit" name="signin_btn">Sign in</button>
    <a href="index.php">Go to Home</a><br>
    <a href="signup.php">Don't have? Create one.</a>
    <p>
        <a class="btn btn-info btn-sm" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
            Admin Login
        </a>
    </p>
    <div class="collapse" id="collapseExample">
        <div class="card card-body">
            Email : admin@gmail.com<br>
            Password : admin
        </div>
    </div>
    <p class="mt-5 mb-3 text-muted">&copy; Laundry.com 2019</p>
</form>

<script src="assets/js/jquery-3.3.1.slim.min.js"></script>
<script>window.jQuery || document.write('<script src="assets/js/jquery-3.3.1.slim.min.js"><\/script>')</script>
<script src="assets/js/bootstrap.bundle.min.js"></script>

</body>
</html>

