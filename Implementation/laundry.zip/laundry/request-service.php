<?php
include "header.php";
$_SESSION['title']='User | Home';
include "functions/message.php";
include "class/request.php";
$request = new request();
?>

<div class="container marketing">

    <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
        <p class="lead">Fill up the form</p>
    </div>

    <div class="container">
        <div class="row justify-content-md-center">
            <div class="card">
                <h5 class="card-header">
                    Request Form
                    <br>
                    <small>
                        <?php
                        $today = date("Y-m-d");
                        echo "Today : ".$today;
                        ?>
                    </small>
                </h5>
                <div class="card-body">
                    <?php
                    if(isset($_POST['select_btn'])){
                        if($_POST['request_time']=="" || $_POST['request_date']==""){
                            danger_message('Sorry','Please fill up all the fields');
                        }elseif($_POST['request_date']<$today){
                            danger_message('Sorry','Invalid Date.');
                        }else{
                            $request->setRequestTime($_POST['request_time']);
                            $request->setRequestDate($_POST['request_date']);
                            $request->setFormToken($_POST['form_token']);
                            $_SESSION['form_token']=$_POST['form_token'];
                            $request->setUserId($_SESSION['user_id']);

                            $request->requestTimeAndDate();
                        }
                    }
                    ?>
                    <form method="post">
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label>Select Pickup Time</label>
                                    <select class="form-control" name="request_time">
                                        <option value="">-- Select --</option>
                                        <option value="08:00 AM - 10:00 AM">08:00 AM - 10:00 AM</option>
                                        <option value="10:00 AM - 12:00 PM">10:00 AM - 12:00 PM</option>
                                        <option value="12:00 AM - 02:00 PM">12:00 AM - 02:00 PM</option>
                                        <option value="02:00 AM - 04:00 PM">02:00 AM - 04:00 PM</option>
                                        <option value="04:00 AM - 06:00 PM">04:00 AM - 06:00 PM</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label>Date</label>
                                    <input type="date" class="form-control" name="request_date">
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="form_token" value="<?php echo rand(1,10000000) ?>">
                        <button type="submit" class="btn btn-primary" name="select_btn">Next</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <hr class="featurette-divider">

</div><!-- /.container -->


<?php
include "footer.php";
?>
