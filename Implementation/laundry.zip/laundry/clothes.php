<?php
session_start();
include "class/request.php";
$request = new request();
include "functions/message.php";
if(isset($_SESSION['user_id'])){
    if($_SESSION['user_id']!='Admin'){
        echo "<script type='text/javascript'>  window.location='user-home.php'; </script>";
    }
}else{
    echo "<script type='text/javascript'>  window.location='signin.php'; </script>";
}

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Admin | Clothes</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="assets/css/admin.css" rel="stylesheet">
    <!-- Favicon-->
    <link rel="icon" href="assets/brand/washing-machine-favicon.png">

</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg fixed-top navbar-dark bg-dark">
    <a class="navbar-brand mr-auto mr-lg-0" href="admin-home.php">
        <img src="assets/brand/washing-machine.png" style="max-height: 36px;max-width: 36px;">
        Administrator Dashboard
    </a>
</nav>

<div class="nav-scroller bg-white shadow-sm">
    <nav class="nav nav-underline">
        <a class="nav-link" href="admin-home.php">Users</a>
        <a class="nav-link " href="notifications.php">
            Notifications
            <span class="badge badge-pill bg-light align-text-bottom"><?php echo $request->countNewNotifications(); ?></span>
        </a>
        <a class="nav-link active" href="clothes.php">Clothes</a>
        <a class="nav-link" href="logout.php">Logout</a>
    </nav>
</div>

<main role="main" class="container">

    <div class="my-3 p-3 bg-white rounded shadow-sm">
        <h6 class="border-bottom border-gray pb-2 mb-0">Edit Clothes Rate</h6>
        <?php
        if(isset($_POST['edit_btn'])){
            if($_POST['cloth']=="" || $_POST['rate']==""){
                danger_message('Sorry', 'Please fill up all the fields');
            }else{
                $request->editClothRate($_POST['cloth'],$_POST['rate']);
            }
        }
        ?>
        <form class="form-inline" style="margin-top: 10px;" method="post">
            <div class="form-group mb-2">
                <select class="form-control" name="cloth">
                    <option value="">-- Select --</option>
                    <?php
                    $clothes = $request->getClothes()->selectAllClothes();
                    $allClothes = $request->getUser()->getConfig()->select($clothes);
                    foreach ($allClothes as $clothRow){
                        echo '<option value="'.$clothRow['cloth_id'].'">'.$clothRow['cloth'].' - £'.$clothRow['rate'].'</option>';
                    }
                    ?>
                </select>
            </div>
            <div class="form-group mx-sm-3 mb-2">
                <input type="number" class="form-control" placeholder="Rate" name="rate">
            </div>
            <button type="submit" class="btn btn-primary mb-2" name="edit_btn">Edit</button>
        </form>
    </div>

    <div class="my-3 p-3 bg-white rounded shadow-sm">
        <h6 class="border-bottom border-gray pb-2 mb-0">Clothes</h6>
        <table class="table table-sm">
            <thead>
            <tr>
                <th scope="col">S.N.</th>
                <th scope="col">Name</th>
                <th scope="col">Rate (£)</th>
                <th scope="col">Image</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $clothes = $request->getClothes()->selectAllClothes();
            $allClothes = $request->getUser()->getConfig()->select($clothes);
            foreach ($allClothes as $cloth){
                echo '<tr>';
                echo '<th scope="row">'.$cloth["cloth_id"].'</th>';
                echo '<td>'.$cloth["cloth"].'</td>';
                echo '<td>'.$cloth["rate"].'</td>';
                echo '<td><img style="max-width: 80px;max-height: 80px;" src="assets/images/'.$cloth["cloth_image"].'"></td>';
                echo '</tr>';
            }
            ?>
            </tbody>
        </table>
    </div>



</main>
<script src="assets/js/jquery-3.3.1.slim.min.js"></script>
<script>window.jQuery || document.write('<script src="assets/js/jquery-3.3.1.slim.min.js"><\/script>')</script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>
