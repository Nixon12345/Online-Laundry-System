<?php
include "header.php";
$_SESSION['title']='User | Home';
include "functions/message.php";
include "class/service.php";
$service = new service();
?>

<div class="container marketing">

    <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
        <p class="lead">Select Clothes</p>
    </div>

    <div class="container">
            <div class="row justify-content-around">
                <div class="col-4">
                    <div class="card">
                        <h5 class="card-header">
                            Select Clothes
                            <br>
                            <small>
                                <?php
                                $today = date("Y-m-d");
                                echo "Today : ".$today;
                                ?>
                            </small>
                        </h5>
                        <div class="card-body">
                            <?php
                            if(isset($_POST['add_btn'])){
                                if($_POST['cloth']=="" || $_POST['quantity']==""){
                                    danger_message('Sorry','Please fill up all the fields.');
                                }else{
                                    $service->setClothId($_POST['cloth']);
                                    $service->setQuantity($_POST['quantity']);
                                    $service->setFormToken($_SESSION['form_token']);

                                    $service->addClothes();
                                }
                            }
                            ?>
                            <form method="post">
                                <div class="row">
                                    <div class="col">
                                        <div class="form-group">
                                            <label>Select Clothes</label>
                                            <select class="form-control" name="cloth">
                                                <option value="">-- Select --</option>
                                                <?php
                                                $allClothes = $service->selectAllClothes();
                                                foreach ($allClothes as $clothRow){
                                                    echo '<option value="'.$clothRow['cloth_id'].'">'.$clothRow['cloth'].' - £'.$clothRow['rate'].'</option>';
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="form-group">
                                            <label>Add Quantity</label>
                                            <input type="number" class="form-control" name="quantity">
                                        </div>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary" name="add_btn">Add</button>
                            </form>

                        </div>
                    </div>
                </div>

                <div class="col-4">
                    <table class="table table-sm">
                        <thead>
                        <th scope="col">S.N.</th>
                        <th scope="col">Clothes</th>
                        <th scope="col">Rate</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">Price</th>
                        <th scope="col">Action</th>
                        </thead>
                        <tbody>
                        <?php
                        $count=0;
                        $total=0;
                        $delete_message = "'Are you sure to delete?'";
                        $cancel_message = "'Are you sure to cancel?'";
                        $confirm_message = "'Are you sure to confirm?'";
                        if(!$service->selectAllService($_SESSION['form_token'])){
                            danger_message('Clothes not added','');
                        }else{
                            $getAllServices = $service->selectAllService($_SESSION['form_token']);
                            foreach ($getAllServices as $service){
                                $count++;
                                echo '<tr>';
                                echo '<th scope="row">'.$count.'</th>';
                                echo '<td>'.$service['cloth'].'</td>';
                                echo '<td>£'.$service['rate'].'</td>';
                                echo '<td>'.$service['quantity'].'</td>';
                                echo '<td>'.$service['rate']*$service['quantity'].'</td>';
                                $total = $service['rate']*$service['quantity']+$total;
                                echo '<td><a onclick ="return confirm('.$delete_message.')"  href="delete_service.php?cloth_id='.$service['cloth_id'].'&&form_token='.$_SESSION['form_token'].'" class="btn btn-dark btn-sm">Delete</a></td>';
                                echo '</tr>';
                            }
                            echo '<div style="background-color: rgb(247, 247, 247);padding: 10px;">';
                            echo '<strong>Request Date : </strong>'.$service['request_date'].'<br>';
                            echo '<strong>Request Time : </strong>'.$service['request_time'].'<br>';
                            echo '<strong>Total : </strong>'.$total.'<br>';
                            echo '<a onclick ="return confirm('.$confirm_message.')"  href="confirm_request.php?form_token='.$_SESSION['form_token'].'&&total='.$total.'" class="btn btn-success btn-sm" style="margin-bottom: 10px; margin-right: 10px;">Confirm</a>';
                            echo '<a onclick ="return confirm('.$cancel_message.')"   href="delete_service.php?form_token='.$_SESSION['form_token'].'" class="btn btn-danger btn-sm" style="margin-bottom: 10px;">Cancel</a>';
                            echo '</div>';
                        }
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>
    </div>

    <hr class="featurette-divider">

</div><!-- /.container -->


<?php
include "footer.php";
?>
