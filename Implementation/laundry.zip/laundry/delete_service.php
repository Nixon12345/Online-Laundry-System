<?php
include "class/service.php";
$service = new service();

$service->setFormToken($_GET['form_token']);
if(isset($_GET['cloth_id']) && isset($_GET['form_token'])){

    $service->setClothId($_GET['cloth_id']);

    $service->deleteService();
    echo "<script type='text/javascript'>  window.location='choose-service.php'; </script>";
}elseif(isset($_GET['form_token'])){
    $service->deleteRequestAndService();
    echo "<script type='text/javascript'>  window.location='user-home.php'; </script>";
}
