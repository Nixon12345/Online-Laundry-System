<?php
include "request.php";
class service{
    private $service_id,$cloth_id,$quantity,$form_token;

    private $request;

    public function __construct()
    {
        $this->request = new request();
    }

    public function getRequest()
    {
        return $this->request;
    }
    public function setRequest($request)
    {
        $this->request = $request;
    }
    public function getServiceId()
    {
        return $this->service_id;
    }
    public function setServiceId($service_id)
    {
        $this->service_id = $service_id;
    }
    public function getClothId()
    {
        return $this->cloth_id;
    }
    public function setClothId($cloth_id)
    {
        $this->cloth_id = $cloth_id;
    }
    public function getQuantity()
    {
        return $this->quantity;
    }
    public function setQuantity($quantity)
    {
        $this->quantity = $quantity;
    }
    public function getFormToken()
    {
        return $this->form_token;
    }
    public function setFormToken($form_token)
    {
        $this->form_token = $form_token;
    }

    public function addClothes(){
        $cloth_id = $this->getClothId();
        $quantity = $this->getQuantity();
        $form_token = $this->getFormToken();


        $checkClothesSQL = "select * from service where cloth_id='$cloth_id' && form_token='$form_token'";
        $data = $this->getRequest()->getUser()->getConfig()->checkRows($checkClothesSQL);
        if($data>0){
            $updateClothesSQL = "update service set quantity=quantity+'$quantity' where cloth_id='$cloth_id' && form_token='$form_token'";
            $this->getRequest()->getUser()->getConfig()->CUD($updateClothesSQL);
        }else{
            $addClothesSQL = "insert into service(cloth_id,quantity,form_token)
                        values ($cloth_id,$quantity,'$form_token')";
            $this->getRequest()->getUser()->getConfig()->CUD($addClothesSQL);
        }
    }

    public function selectAllClothes(){
        $selectAllClothesSQL = "select * from clothes";
        return $this->getRequest()->getUser()->getConfig()->select($selectAllClothesSQL);
    }

    public function selectAllService($form_token){
        $selectAllRequest = "select * from request r,clothes c,service s where r.form_token='$form_token' and s.form_token='$form_token' and s.cloth_id=c.cloth_id";
        return $this->getRequest()->getUser()->getConfig()->select($selectAllRequest);
    }

    public function deleteService(){
        $cloth_id = $this->getClothId();
        $form_token = $this->getFormToken();

        $deleteService = "delete from service where form_token='$form_token' && cloth_id=$cloth_id";
        $this->getRequest()->getUser()->getConfig()->CUD($deleteService);
    }

    public function deleteRequestAndService(){
        $form_token = $this->getFormToken();

        $deleteRequest = "delete from request where form_token='$form_token'";
        $this->getRequest()->getUser()->getConfig()->CUD($deleteRequest);
        $deleteService = "delete from service where form_token='$form_token'";
        $this->getRequest()->getUser()->getConfig()->CUD($deleteService);
    }



}