<?php
class clothes{
    private $cloth_id,$cloth,$rate;

    public function getClothId()
    {
        return $this->cloth_id;
    }
    public function setClothId($cloth_id)
    {
        $this->cloth_id = $cloth_id;
    }
    public function getCloth()
    {
        return $this->cloth;
    }
    public function setCloth($cloth)
    {
        $this->cloth = $cloth;
    }
    public function getRate()
    {
        return $this->rate;
    }
    public function setRate($rate)
    {
        $this->rate = $rate;
    }

    public function selectAllClothes(){
        $selectAllClothesSQL = "select * from clothes";
        return $selectAllClothesSQL;
    }

}