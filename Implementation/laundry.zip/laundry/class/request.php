<?php
include "user.php";
include "clothes.php";
class request{
    private $request_id,$request_time,$request_date,$status=false,$form_complete=false,$form_token,$user_id,$total;

    private $user;
    private $clothes;

    public function __construct()
    {
        $this->user = new user();
        $this->clothes = new clothes();
    }

    public function getTotal()
    {
        return $this->total;
    }
    public function setTotal($total)
    {
        $this->total = $total;
    }
    public function isFormComplete()
    {
        return $this->form_complete;
    }
    public function setFormComplete($form_complete)
    {
        $this->form_complete = $form_complete;
    }
    public function getClothes()
    {
        return $this->clothes;
    }
    public function setClothes($clothes)
    {
        $this->clothes = $clothes;
    }
    public function getUser()
    {
        return $this->user;
    }
    public function setUser($user)
    {
        $this->user = $user;
    }
    public function getRequestId()
    {
        return $this->request_id;
    }
    public function setRequestId($request_id)
    {
        $this->request_id = $request_id;
    }
    public function getRequestTime()
    {
        return $this->request_time;
    }
    public function setRequestTime($request_time)
    {
        $this->request_time = $request_time;
    }
    public function getRequestDate()
    {
        return $this->request_date;
    }
    public function setRequestDate($request_date)
    {
        $this->request_date = $request_date;
    }
    public function isStatus()
    {
        return $this->status;
    }
    public function setStatus($status)
    {
        $this->status = $status;
    }
    public function getFormToken()
    {
        return $this->form_token;
    }
    public function setFormToken($form_token)
    {
        $this->form_token = $form_token;
    }
    public function getUserId()
    {
        return $this->user_id;
    }
    public function setUserId($user_id)
    {
        $this->user_id = $user_id;
    }

    public function requestTimeAndDate(){
        $request_time = $this->getRequestTime();
        $request_date = $this->getRequestDate();
        $form_token = $this->getFormToken();
        $status = $this->isStatus();
        $form_complete = $this->isFormComplete();
        $user_id = $this->getUserId();

        $insertTimeAndDateSQL = "insert into request(request_time,request_date,status,form_complete,form_token,user_id,total,date)
                                 values ('$request_time','$request_date','$status','$form_complete','$form_token','$user_id',0,now())";
        $this->getUser()->getConfig()->CUD($insertTimeAndDateSQL);
        echo "<script type='text/javascript'>  window.location='choose-service.php'; </script>";
    }

    public function confirmRequest(){
        $form_token = $this->getFormToken();
        $total = $this->getTotal();

        $updateRequest = "update request set total=$total,form_complete=true where form_token='$form_token'";
        $this->getUser()->getConfig()->CUD($updateRequest);
    }

    public function getAllUserRequest($user_id){
        $selectAllRequest="select * from request r where r.user_id=$user_id";
        return $this->getUser()->getConfig()->select($selectAllRequest);
    }

    public function getALlRequestAndService($form_token){
        $getAllRequestAndService = "select * from request r,service s,clothes c where r.form_token=s.form_token and s.cloth_id=c.cloth_id and r.form_token='$form_token'";
        return $this->getUser()->getConfig()->select($getAllRequestAndService);
    }

    public function getALLRequest(){
        $getALLRequest = "select * from request";
        return $this->getUser()->getConfig()->select($getALLRequest);
    }

    public function getUserRequest(){
        $getUserRequest = "select * from request r,user u where u.user_id=r.user_id";
        return $this->getUser()->getConfig()->select($getUserRequest);
    }

    public function getALLUser(){
        $getAllUser = "select * from user order by user_id desc";
        return $this->getUser()->getConfig()->select($getAllUser);
    }

    public function countNewNotifications(){
        $countNewNotifications = "select * from request where status=false";
        return $this->getUser()->getConfig()->checkRows($countNewNotifications);
    }

    public function getRequestService($form_token){
        $getRequestService = "select * from service s,clothes c where s.cloth_id=c.cloth_id and s.form_token='$form_token'";
        return $this->getUser()->getConfig()->select($getRequestService);
    }

    public function adminConfirmRequest($form_token){
        $confirmRequest = "update request set status=true where form_token='$form_token'";
        $this->getUser()->getConfig()->CUD($confirmRequest);
    }

    public function editClothRate($cloth_id,$rate){
        $editClothRate = "update clothes set rate=$rate where cloth_id=$cloth_id";
        $this->getUser()->getConfig()->CUD($editClothRate);
    }


}