<?php
include "header.php";
$_SESSION['title']='User | Home';
include "class/request.php";
$request = new request();
include "functions/message.php";
?>

    <div class="container marketing">

        <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
            <?php
            if(isset($_GET['success'])){
                success_message('Thank you ','for using our service.');
            }
            ?>
            <h1 class="display-4">Laundry.com</h1>
            <p class="lead">Giving you time back for the important things!</p>
            <p class="lead"><strong>Pricing</strong></p>
            <a class="btn btn-lg btn-success" href="request-service.php" role="button">Request Service</a>
        </div>

        <div class="container">
                <div class="row">
                    <?php
                    $clothes = $request->getClothes()->selectAllClothes();
                    $getAllClothes = $request->getUser()->getConfig()->select($clothes);
                    foreach ($getAllClothes as $allClothes){
                        echo '<div class="col-4 cloth-panel-margin">';
                        echo '<div class="card">';
                        echo '<div class="card-header">';
                        echo '<strong>'.$allClothes['cloth'].'</strong>';
                        echo '</div>';
                        echo '<div class="card-body">';
                        echo '<img src="assets/images/'.$allClothes['cloth_image'].'" class="rounded mx-auto d-block" width="140" height="140" />';
                        echo '<h5 class="card-title text-center">Pricing</h5>';
                        echo '<p class="card-text text-center">£'.$allClothes['rate'].' (per piece)</p>';
                        echo '</div>';
                        echo '</div>';
                        echo '</div>';
                    }
                    ?>
                </div>

        </div>

        <hr class="featurette-divider">

    </div><!-- /.container -->

<?php
include "footer.php";
?>