
<!-- FOOTER -->
<footer class="container">
    <p class="float-right"><a href="#">Back to top</a></p>
    <p>&copy; 2019 Laundry.com</p>
</footer>

</main>

<script src="assets/js/jquery-3.3.1.slim.min.js"></script>
<script>window.jQuery || document.write('<script src="assets/js/jquery-3.3.1.slim.min.js"><\/script>')</script>
<script src="assets/js/bootstrap.bundle.min.js"></script>

</body>
</html>
