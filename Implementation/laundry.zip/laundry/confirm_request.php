<?php
session_start();
include "class/request.php";
$request = new request();

if(isset($_GET['adminConfirm'])){
    $request->adminConfirmRequest($_GET['adminConfirm']);
    echo "<script type='text/javascript'>  window.location='notifications.php'; </script>";
}

$request->setFormToken($_GET['form_token']);
$request->setTotal($_GET['total']);
$request->confirmRequest();
unset($_SESSION['form_token']);
echo "<script type='text/javascript'>  window.location='user-home.php?success'; </script>";
