<?php
include "header.php";
$_SESSION['title']='User | Change Password';
include "functions/message.php";
include "class/user.php";
$user = new user();
?>

    <div class="container marketing">

        <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">

            <h1 class="display-4">Change Password</h1>
            <?php
            if(isset($_POST['change_btn'])){
                if($_POST['old_password']=="" || $_POST['new_password']=="" || $_POST['confirm_password']==""){
                    danger_message('Sorry','Please fill up all the fields.');
                }else{
                    if($_POST['new_password']==$_POST['confirm_password']){
                        $user_id = $_SESSION['user_id'];
                        if($user->changePassword($_POST['old_password'],$_POST['new_password'],$user_id)){
                            success_message('Congratulations','Password changed successfully.');
                        }else{
                            danger_message('Sorry','Old Password does not match.');
                        }
                    }else{
                        danger_message('Sorry','Confirm your password again.');
                    }
                }
            }
            ?>
            <form method="post">
                <div class="form-group">
                    <label>Old Password</label>
                    <input type="password" class="form-control" placeholder="Old Password" name="old_password" tabindex="1">
                </div>
                <div class="form-group">
                    <label>New Password</label>
                    <input type="password" class="form-control" placeholder="New Password" name="new_password" tabindex="2">
                </div>
                <div class="form-group">
                    <label>Confirm Password</label>
                    <input type="password" class="form-control" placeholder="Confirm Password" name="confirm_password" tabindex="3">
                </div>
                <button type="submit" name="change_btn" class="btn btn-success">Change</button>
            </form>

        </div>


        <hr class="featurette-divider">

    </div><!-- /.container -->

<?php
include "footer.php";
?>
