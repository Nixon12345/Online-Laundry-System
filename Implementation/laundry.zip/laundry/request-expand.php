<?php
include "header.php";
$_SESSION['title']='User | My-Request';
include "class/request.php";
$request = new request();
include "functions/message.php";
?>

<div class="container marketing">


    <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">

        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="my-request.php">My Request</a></li>
                <li class="breadcrumb-item active" aria-current="page">Services</li>
            </ol>
        </nav>

        <h1 class="display-4">My Request's Services</h1>

        <table class="table table-sm">
            <thead>
            <tr>
                <th scope="col">S.N.</th>
                <th scope="col">Cloth</th>
                <th scope="col">Rate</th>
                <th scope="col">Quantity</th>
            </tr>
            </thead>
            <tbody>
            <?php

            $count=0;
            if(!$request->getALlRequestAndService($_GET['form_token'])){
                danger_message('Sorry','0 Data');
            }else{
                $getAllUserRequestAndService = $request->getALlRequestAndService($_GET['form_token']);
                foreach ($getAllUserRequestAndService as $requestRow){
                    $count++;
                    echo '<tr>';
                    echo '<th scope="row">'.$count.'</th>';
                    echo '<td>'.$requestRow["cloth"].'</td>';
                    echo '<td>£'.$requestRow["rate"].'</td>';
                    echo '<td>'.$requestRow["quantity"].'</td>';
                    echo '</tr>';
                }
                echo '<strong>Request Time : </strong>'.$requestRow['request_time'].'<br>';
                echo '<strong>Request Date : </strong>'.$requestRow['request_date'].'<br>';
                echo '<strong>Total : </strong>'.$requestRow['total'].'<br>';
            }
            ?>
            </tbody>
        </table>

    </div>


    <hr class="featurette-divider">

</div><!-- /.container -->

<?php
include "footer.php";
?>
