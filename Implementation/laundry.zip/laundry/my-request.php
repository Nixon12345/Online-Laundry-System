<?php
include "header.php";
$_SESSION['title']='User | My-Request';
include "class/request.php";
$request = new request();
include "functions/message.php";
?>

<div class="container marketing">

    <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">

        <h1 class="display-4">My Request</h1>

        <table class="table table-sm">
            <thead>
            <tr>
                <th scope="col">S.N.</th>
                <th scope="col">Request</th>
                <th scope="col">Total</th>
                <th scope="col">Form Complete</th>
                <th scope="col">Status</th>
                <th scope="col">Date</th>
                <th scope="col">Action</th>
            </tr>
            </thead>
            <tbody>
            <?php
            $count=0;
            $delete_message = "'Are you sure to delete?'";
            if(!$request->getAllUserRequest($_SESSION['user_id'])){
                danger_message('Empty', 'You have not used our service yet?');
            }else{
                $getAllUserRequest = $request->getAllUserRequest($_SESSION['user_id']);
                foreach ($getAllUserRequest as $requestRow){
                    $count++;
                    echo '<tr>';
                    echo '<th scope="row">'.$count.'</th>';
                    echo '<td>
                                <strong>Time : </strong>'.$requestRow["request_time"].'<br>                                
                                <strong>Date : </strong>'.$requestRow["request_date"].'
                          </td>';
                    echo '<td>£'.$requestRow["total"].'</td>';
                    if($requestRow['form_complete']){
                        echo '<td><span class="badge badge-pill badge-primary">Completed</span></td>';
                    }else{
                        echo '<td><span class="badge badge-pill badge-danger">In-Completed</span></td>';
                    }
                    if($requestRow['status']){
                        echo '<td><span class="badge badge-pill badge-primary">Confirmed</span></td>';
                    }else{
                        echo '<td><span class="badge badge-pill badge-danger">Not-Confirmed</span></td>';
                    }
                    echo '<td>'.$requestRow["date"].'</td>';
                    echo '<td>
                            <a href="request-expand.php?form_token='.$requestRow["form_token"].'" class="btn btn-info btn-sm" title="Expand">Expand</a>                            
                            <a onclick ="return confirm('.$delete_message.')" href="delete_service.php?form_token='.$requestRow["form_token"].'" class="btn btn-danger btn-sm" title="Delete">Delete</a>                            
                            </td>';
                    echo '</tr>';
                }
            }
            ?>
            </tbody>
        </table>

    </div>


    <hr class="featurette-divider">

</div><!-- /.container -->

<?php
include "footer.php";
?>
