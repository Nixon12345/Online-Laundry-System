<?php
$connection = mysqli_connect("127.0.0.1","root","");
$createDatabase = "create database laundry";
mysqli_query($connection,$createDatabase);
$actualConnection = mysqli_connect("127.0.0.1","root","","laundry");

mysqli_query($actualConnection,"CREATE TABLE `clothes` (
  `cloth_id` int(11) NOT NULL,
  `cloth` varchar(255) NOT NULL,
  `rate` int(11) NOT NULL,
  `cloth_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1");

mysqli_query($actualConnection,"INSERT INTO `clothes` (`cloth_id`, `cloth`, `rate`, `cloth_image`) VALUES
(1, 'Shirt/T-Shirt', 20, 'shirt.jpg'),
(2, 'Pant', 30, 'pant.png'),
(3, 'Hoodies', 10, 'hoodies.jpg'),
(4, 'Leather Jacket', 40, 'jacket.jpg'),
(5, 'Coat', 100, 'coat.png'),
(6, 'Bed Sheet', 20, 'bed-sheet.jpg')");

mysqli_query($actualConnection,"CREATE TABLE `request` (
  `request_id` int(11) NOT NULL,
  `request_time` varchar(255) NOT NULL,
  `request_date` date NOT NULL,
  `status` tinyint(1) NOT NULL,
  `form_complete` tinyint(1) NOT NULL,
  `form_token` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1");

mysqli_query($actualConnection,"INSERT INTO `request` (`request_id`, `request_time`, `request_date`, `status`, `form_complete`, `form_token`, `user_id`, `total`, `date`) VALUES
(23, '08:00 AM - 10:00 AM', '2019-01-24', 1, 1, '5294367', 2, 120, '2019-01-22')");

mysqli_query($actualConnection,"CREATE TABLE `service` (
  `service_id` int(11) NOT NULL,
  `cloth_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `form_token` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1");

mysqli_query($actualConnection,"INSERT INTO `service` (`service_id`, `cloth_id`, `quantity`, `form_token`) VALUES
(38, 2, 4, '5294367')");

mysqli_query($actualConnection,"CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1");

mysqli_query($actualConnection,"INSERT INTO `user` (`user_id`, `name`, `address`, `email`, `password`) VALUES
(2, 'Muskan Khadka', 'Pokhara', 'muskankhadka@gmail.com', 'muskan')");

mysqli_query($actualConnection,"ALTER TABLE `clothes`
  ADD PRIMARY KEY (`cloth_id`)");

mysqli_query($actualConnection,"ALTER TABLE `request`
  ADD PRIMARY KEY (`request_id`)");

mysqli_query($actualConnection,"ALTER TABLE `service`
  ADD PRIMARY KEY (`service_id`)");

mysqli_query($actualConnection,"ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`)");

mysqli_query($actualConnection,"ALTER TABLE `clothes`
  MODIFY `cloth_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7");

mysqli_query($actualConnection,"ALTER TABLE `request`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24");

mysqli_query($actualConnection,"ALTER TABLE `service`
  MODIFY `service_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39");

mysqli_query($actualConnection,"ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3");

mysqli_query($actualConnection,"COMMIT");

header("location:index.php");