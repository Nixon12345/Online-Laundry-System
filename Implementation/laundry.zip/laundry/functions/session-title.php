<?php
if($_SESSION['title']){
    echo $_SESSION['title'];
}else{
    echo "Welcome | Laundry.com";
}
