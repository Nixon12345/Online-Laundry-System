<?php
session_start();
if(isset($_SESSION['user_id'])){
    if($_SESSION['user_id']=='Admin'){
        echo "<script type='text/javascript'>  window.location='admin-home.php'; </script>";
    }else{
        echo "<script type='text/javascript'>  window.location='user-home.php'; </script>";
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>
        Sign up
    </title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="assets/css/signin.css" rel="stylesheet">
    <!-- Favicon-->
    <link rel="icon" href="assets/brand/washing-machine-favicon.png">

</head>

<body class="text-center">

<form class="form-signin" method="post">

    <?php
    include "class/user.php";
    include "functions/message.php";
    $user = new user();
    if(isset($_POST['signup_btn'])){

        if($_POST['name']=="" || $_POST['address']=="" || $_POST['email']=="" || $_POST['password']==""){
            danger_message('Sorry','Please fill up all the fields.');
        }else{
            $user->setName($_POST['name']);
            $user->setAddress($_POST['address']);
            $user->setEmail($_POST['email']);
            $user->setPassword($_POST['password']);

            if($user->user_create()){
                success_message('Congratulations','Successfully registered.');
            }else{
                danger_message('Sorry','Email already exists. Try again!');
            }
        }
    }
    ?>


    <h1 class="h3 mb-3 font-weight-normal">Laundry.com</h1>
    <img class="mb-4" src="assets/brand/washing-machine.svg" alt="brand image" width="72" height="72">
    <h2 class="h4 mb-4 font-weight-normal">Please sign up</h2>
    <input type="text" class="form-control" placeholder="Name" name="name" autofocus>
    <input type="text" class="form-control" placeholder="Address" name="address">
    <input type="email" class="form-control" placeholder="Email Address" name="email">
    <input type="password" class="form-control" placeholder="Password" name="password">
    <button class="btn btn-lg btn-primary btn-block" type="submit" name="signup_btn">Sign up</button>
    <a href="index.php">Go to Home</a><br>
    <a href="signin.php">Sign in</a>
    <p class="mt-5 mb-3 text-muted">&copy; Laundry.com 2019</p>

</form>

<script src="assets/js/jquery-3.3.1.slim.min.js"></script>
<script>window.jQuery || document.write('<script src="assets/js/jquery-3.3.1.slim.min.js"><\/script>')</script>
<script src="assets/js/bootstrap.bundle.min.js"></script>


</body>
</html>

